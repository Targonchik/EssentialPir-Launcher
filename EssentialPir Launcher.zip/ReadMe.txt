EssentialPir
PASTE 1.16.5
EssentialPir Это паста которая может заменить вам Essential, который на лицензии.

Для работы мода вам понадобиться Pir Launcher...
Чтобы его запустить, вам надо разархивировать DLLMASTER и EssentialPir на рабочий стол, и открыть от имени администратора.



КОДЕР: RUDOS, MORJ, TARGONCHIK.